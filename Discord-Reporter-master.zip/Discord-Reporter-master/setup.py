import os

os.system('pip install requests')
print('\nFinished.')
os.system('pause >NUL')
